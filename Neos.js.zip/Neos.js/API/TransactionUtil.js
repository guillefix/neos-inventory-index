class TransactionUtil {
	static get NCR_CONVERSION_VARIABLE() {
		return "NCR_CONVERSION";
	}
	static get CDFT_CONVERSION_VARIABLE() {
		return "CDFT_CONVERSION";
	}
}
module.exports = {
	TransactionUtil,
};
