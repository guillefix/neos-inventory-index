class CryptoHelper {}
module.exports = {
	CryptoHelper,
};
