/**
 * Out Variable
 * @class Out
 * @property {*} Out
 */
class Out {
	/**
	 *Creates an instance of Out.
	 * @memberof Out
	 */
	constructor() {
		let self = [];
		self.Out = new Object();
		return self;
	}
}
module.exports = {
	Out,
};
