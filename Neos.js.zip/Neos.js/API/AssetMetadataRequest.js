class AssetMetadataRequest {
	static get MAX_BATCH_SIZE() {
		return 32;
	}
}
module.exports = {
	AssetMetadataRequest,
};
