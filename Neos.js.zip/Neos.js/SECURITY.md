# Security Policy

## Supported Versions

We will update older versions to patch any found security issues, However it is generally advised to use the latest build

| Version | Supported          |
| ------- | ------------------ |
| 1.x     | :white_check_mark: |
| < 1.0   | :x:                |

## Reporting a Vulnerability

If you find a vulnerability DM Bitman#0669 on our [Discord](https://discord.gg/6y2A4Pk) or Contact us at Contact@polylogix.studio
